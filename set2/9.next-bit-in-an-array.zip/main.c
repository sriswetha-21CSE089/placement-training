/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[]={1,2,4,5,9};
   int len=sizeof(a)/sizeof(a[0]);
   int i=0,j;
   while(i<len){
       j=0;
       while(j<len){
           if(a[i]+1==a[j]){
               printf("[%d,%d] ",a[i],a[j]);
               break;
           }
           else{
               j++;
           }
       }
       i++;
   }

    return 0;
}
