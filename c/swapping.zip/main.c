/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1=10,num2=20;
    num1=num1+num2;
    num2=num1-num2;
    num1=num1-num2;
    printf("num1=%d\n",num1);
    printf("num2=%d",num2);
    return 0;
    
}
